package com.TestScripts;


import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.PageObjects.PageObjects;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class AppiumTest1 {
	static AppiumDriver<MobileElement> driver = null;
	
	@Test
	public void run() throws InterruptedException
	{
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName","Pixel XL API 29");
		caps.setCapability("udid","emulator-5554");
		caps.setCapability("platformName","Android");
		caps.setCapability("platformVersion","10.0");
		caps.setCapability("browserName","Chrome");
		caps.setCapability("noReset","true");
		
		System.setProperty("webdriver.chrome.driver","C:\\JavaEclipse\\MITS_Framework\\Resources\\chromedriver.exe");
		
		
		try {
			driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"),caps);
		}
		catch(MalformedURLException e)
		{
			System.out.println(e.getMessage());
		}
		
		driver.get("https://www.statefarm.com/");
		Thread.sleep(5000);
		driver.findElement(By.cssSelector(PageObjects.txt_StartQuoteZipCode_CSS)).sendKeys("61704");
		driver.findElement(By.cssSelector(PageObjects.btn_startQuote_CSS)).click();
		Thread.sleep(5000);
		driver.findElement(By.cssSelector(PageObjects.txt_FirstName_CSS)).sendKeys("Ravi");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(PageObjects.txt_LastName_CSS)).sendKeys("Chandra");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(PageObjects.txt_StreetAddress_CSS)).sendKeys("3 Smoketree CT");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(PageObjects.txt_APTUNIT_CSS)).sendKeys("32");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(PageObjects.txt_DateOfBirth_CSS)).sendKeys("02/07/1985");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(PageObjects.txt_PolicyStartDate_CSS)).sendKeys("10/09/2020");
		Thread.sleep(3000);
		driver.hideKeyboard();
		Thread.sleep(3000);
		MobileSwipeDown(driver,0.5,0.8,0.5,0.2);
		MobileSwipeDown(driver,0.5,0.8,0.5,0.2);
	}
	
	public static void MobileSwipeDown(AppiumDriver<MobileElement> driver,double start_xd,double start_yd,double end_xd,double end_yd)
	{
		Dimension dimension = driver.manage().window().getSize();
		
		int start_x = (int)(dimension.width*start_xd);
		int start_y = (int)(dimension.height*start_yd);
		
		int end_x = (int)(dimension.width*end_xd);
		int end_y = (int)(dimension.height*end_yd);
	
		new TouchAction((PerformsTouchActions)driver)
		.press(PointOption.point(start_x,start_y))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
		.moveTo(PointOption.point(end_x,end_y))
		.release().perform();
	}

}
